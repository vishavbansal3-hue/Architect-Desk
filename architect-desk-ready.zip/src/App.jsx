
/*
Architect Desk - Single-file React prototype (trimmed)
This file contains the full functional prototype that uses localStorage for persistence.
*/
import React, { useEffect, useState } from 'react'

// Utility: localStorage wrapper
const useLocalState = (key, initial) => {
  const [state, setState] = useState(() => {
    try {
      const raw = localStorage.getItem(key)
      return raw ? JSON.parse(raw) : initial
    } catch (e) {
      return initial
    }
  })
  useEffect(() => {
    localStorage.setItem(key, JSON.stringify(state))
  }, [key, state])
  return [state, setState]
}

// Sample starter data
const SAMPLE = {
  clients: [
    { id: 'c1', name: 'Aman Kumar', phone: '9876543210' },
    { id: 'c2', name: 'Neha Shah', phone: '9988776655' },
  ],
  employees: [
    { id: 'e1', name: 'Ravi', role: 'Architect' },
    { id: 'e2', name: 'Sonia', role: 'Drafter' },
  ],
  projects: [
    {
      id: 'p1',
      title: 'Residential - Plot 32',
      clientId: 'c1',
      stage: 'A', // A, B, C
      notes: 'Rough sketches done',
      payments: { total: 20000, received: 5000 },
      assignedTo: null,
      files: [],
      createdAt: Date.now(),
    },
  ],
  nocs: [],
  valuations: [],
}

// Small helpers
const uid = (prefix = '') => prefix + Math.random().toString(36).slice(2, 9)

export default function App() {
  const [clients, setClients] = useLocalState('ad_clients', SAMPLE.clients)
  const [employees, setEmployees] = useLocalState('ad_employees', SAMPLE.employees)
  const [projects, setProjects] = useLocalState('ad_projects', SAMPLE.projects)
  const [nocs, setNocs] = useLocalState('ad_nocs', SAMPLE.nocs)
  const [valuations, setValuations] = useLocalState('ad_valuations', SAMPLE.valuations)

  const [route, setRoute] = useState('dashboard')

  // Simple aggregated stats
  const totalPendingPayments = projects.reduce((s, p) => s + Math.max(0, (p.payments?.total || 0) - (p.payments?.received || 0)), 0)

  // CRUD operations: Projects
  const addProject = (data) => {
    const p = { id: uid('p'), createdAt: Date.now(), stage: 'A', files: [], payments: { total: data.total || 0, received: 0 }, assignedTo: null, ...data }
    setProjects([p, ...projects])
  }
  const updateProject = (id, patch) => setProjects(projects.map(p => p.id === id ? { ...p, ...patch } : p))
  const deleteProject = (id) => setProjects(projects.filter(p => p.id !== id))

  // NOC operations
  const addNoc = (data) => setNocs([{ id: uid('n'), status: 'collected', logs: [], createdAt: Date.now(), ...data }, ...nocs])
  const updateNoc = (id, patch) => setNocs(nocs.map(n => n.id === id ? { ...n, ...patch } : n))

  // Valuation operations
  const addValuation = (data) => setValuations([{ id: uid('v'), status: 'site-visit', logs: [], createdAt: Date.now(), ...data }, ...valuations])
  const updateValuation = (id, patch) => setValuations(valuations.map(v => v.id === id ? { ...v, ...patch } : v))

  // Simple UI
  return (
    <div className="min-h-screen bg-gray-50 text-gray-800">
      <div className="max-w-5xl mx-auto p-4">
        <Header onRoute={setRoute} route={route} totalPendingPayments={totalPendingPayments} />

        <main className="mt-4">
          {route === 'dashboard' && (
            <Dashboard
              projects={projects}
              nocs={nocs}
              valuations={valuations}
              clients={clients}
              employees={employees}
              onNavigate={setRoute}
              onAddProject={addProject}
            />
          )}

          {route === 'projects' && (
            <ProjectsPage
              projects={projects}
              clients={clients}
              employees={employees}
              onAdd={addProject}
              onUpdate={updateProject}
              onDelete={deleteProject}
            />
          )}

          {route === 'nocs' && (
            <NocPage nocs={nocs} clients={clients} onAdd={addNoc} onUpdate={updateNoc} />
          )}

          {route === 'valuations' && (
            <ValuationPage valuations={valuations} banks={[]} clients={clients} onAdd={addValuation} onUpdate={updateValuation} />
          )}

          {route === 'clients' && (
            <ClientsPage clients={clients} employees={employees} setClients={setClients} setEmployees={setEmployees} />
          )}

          {route === 'payments' && (
            <PaymentsPage projects={projects} onUpdate={updateProject} />
          )}
        </main>

        <MobileNav route={route} setRoute={setRoute} />
      </div>
    </div>
  )
}

function Header({ onRoute, route, totalPendingPayments }) {
  return (
    <header className="flex items-center justify-between">
      <div>
        <h1 className="text-2xl font-bold">Architect Desk</h1>
        <p className="text-sm text-gray-600">Simple office workflow for architects</p>
      </div>
      <div className="flex items-center gap-4">
        <div className="text-right">
          <div className="text-xs text-gray-500">Pending payments</div>
          <div className="font-semibold">₹{totalPendingPayments}</div>
        </div>
        <button onClick={() => onRoute('projects')} className="px-3 py-2 bg-teal-600 text-white rounded-md text-sm">New Project</button>
      </div>
    </header>
  )
}

function Dashboard({ projects, nocs, valuations, clients, employees, onNavigate, onAddProject }) {
  return (
    <div className="space-y-4">
      <section className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card title="Projects" action={() => onNavigate('projects')}>
          <div className="text-3xl font-bold">{projects.length}</div>
          <div className="text-sm text-gray-500">Open projects</div>
        </Card>

        <Card title="NOC & Drawings" action={() => onNavigate('nocs')}>
          <div className="text-3xl font-bold">{nocs.length}</div>
          <div className="text-sm text-gray-500">Files in progress</div>
        </Card>

        <Card title="Valuations" action={() => onNavigate('valuations')}>
          <div className="text-3xl font-bold">{valuations.length}</div>
          <div className="text-sm text-gray-500">Valuation jobs</div>
        </Card>
      </section>

      <section className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <h2 className="text-lg font-semibold mb-2">Recent Projects</h2>
          <div className="space-y-2">
            {projects.slice(0,5).map(p => (
              <div key={p.id} className="p-3 bg-white rounded-md shadow-sm flex justify-between">
                <div>
                  <div className="font-medium">{p.title}</div>
                  <div className="text-xs text-gray-500">Stage {p.stage} • ₹{p.payments?.total} • {p.assignedTo ? `Assigned` : 'Unassigned'}</div>
                </div>
                <div className="text-sm text-gray-500">{new Date(p.createdAt).toLocaleDateString()}</div>
              </div>
            ))}
            {projects.length === 0 && <div className="text-sm text-gray-500">No projects yet — create one.</div>}
          </div>
        </div>

        <div>
          <h2 className="text-lg font-semibold mb-2">Quick Actions</h2>
          <div className="space-y-2">
            <button onClick={() => onNavigate('projects')} className="w-full text-left p-3 bg-white rounded-md shadow-sm">Manage Projects</button>
            <button onClick={() => onNavigate('nocs')} className="w-full text-left p-3 bg-white rounded-md shadow-sm">NOC & Submissions</button>
            <button onClick={() => onNavigate('valuations')} className="w-full text-left p-3 bg-white rounded-md shadow-sm">Valuation Reports</button>
            <button onClick={() => onNavigate('clients')} className="w-full text-left p-3 bg-white rounded-md shadow-sm">Clients & Employees</button>
          </div>
        </div>
      </section>
    </div>
  )
}

function Card({ title, children, action }) {
  return (
    <div className="p-4 bg-white rounded-md shadow-sm flex flex-col justify-between">
      <div className="flex justify-between items-start">
        <div>
          <div className="text-sm text-gray-500">{title}</div>
        </div>
        {action && <button onClick={action} className="text-xs text-teal-600 underline">Open</button>}
      </div>

      <div className="mt-4">{children}</div>
    </div>
  )
}

function MobileNav({ route, setRoute }) {
  const items = [
    { id: 'dashboard', label: 'Home' },
    { id: 'projects', label: 'Projects' },
    { id: 'nocs', label: 'NOC' },
    { id: 'valuations', label: 'Val' },
    { id: 'clients', label: 'Contacts' },
  ]
  return (
    <nav className="fixed bottom-4 left-0 right-0 max-w-5xl mx-auto px-4">
      <div className="bg-white rounded-full shadow-md flex justify-between px-3 py-2">
        {items.map(it => (
          <button key={it.id} onClick={() => setRoute(it.id)} className={`flex-1 text-xs py-2 ${route===it.id? 'font-semibold text-teal-600':'text-gray-600'}`}>{it.label}</button>
        ))}
      </div>
    </nav>
  )
}

// Projects page with add form and list
function ProjectsPage({ projects, clients, employees, onAdd, onUpdate, onDelete }) {
  const [form, setForm] = useState({ title: '', clientId: clients[0]?.id || '', total: 0 })

  useEffect(() => { if (!form.clientId && clients[0]) setForm(f => ({ ...f, clientId: clients[0].id })) }, [clients])

  const submit = (e) => {
    e.preventDefault();
    if (!form.title) return alert('Title required')
    onAdd({ ...form })
    setForm({ title: '', clientId: clients[0]?.id || '', total: 0 })
  }

  return (
    <div className="space-y-4">
      <h2 className="text-lg font-semibold">Projects</h2>
      <form onSubmit={submit} className="grid grid-cols-1 md:grid-cols-3 gap-2 items-end">
        <div>
          <label className="text-sm">Title</label>
          <input value={form.title} onChange={e=>setForm({...form,title:e.target.value})} className="w-full p-2 rounded-md border" />
        </div>
        <div>
          <label className="text-sm">Client</label>
          <select value={form.clientId} onChange={e=>setForm({...form,clientId:e.target.value})} className="w-full p-2 rounded-md border">
            {clients.map(c=> <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </div>
        <div>
          <label className="text-sm">Total Fee (₹)</label>
          <input type="number" value={form.total} onChange={e=>setForm({...form,total: parseInt(e.target.value||0)})} className="w-full p-2 rounded-md border" />
        </div>
        <div className="md:col-span-3">
          <button type="submit" className="px-4 py-2 bg-teal-600 text-white rounded-md">Create Project</button>
        </div>
      </form>

      <div className="space-y-2">
        {projects.map(p => (
          <ProjectCard key={p.id} p={p} clients={clients} employees={employees} onUpdate={onUpdate} onDelete={onDelete} />
        ))}
        {projects.length===0 && <div className="text-sm text-gray-500">No projects yet — create a new one.</div>}
      </div>
    </div>
  )
}

function ProjectCard({ p, clients, employees, onUpdate, onDelete }) {
  const client = clients.find(c => c.id === p.clientId)
  const assign = (id) => onUpdate(p.id, { assignedTo: id })
  const advanceStage = () => onUpdate(p.id, { stage: p.stage === 'A' ? 'B' : p.stage === 'B' ? 'C' : 'C' })
  const recordPayment = () => {
    const add = parseInt(prompt('Amount received (₹)', '0') || '0')
    if (add>0) onUpdate(p.id, { payments: { ...p.payments, received: (p.payments?.received||0) + add } })
  }

  return (
    <div className="p-3 bg-white rounded-md shadow-sm flex flex-col md:flex-row md:justify-between gap-2">
      <div>
        <div className="font-medium">{p.title}</div>
        <div className="text-xs text-gray-500">Client: {client?.name || '—'} • Stage {p.stage}</div>
        <div className="text-xs text-gray-500">Fee: ₹{p.payments?.total} • Received: ₹{p.payments?.received || 0}</div>
      </div>
      <div className="flex gap-2 items-center">
        <select onChange={e=>assign(e.target.value)} className="p-2 border rounded-md text-sm">
          <option value="">Assign</option>
          {employees.map(emp=> <option key={emp.id} value={emp.id}>{emp.name}</option>)}
        </select>
        <button onClick={advanceStage} className="px-2 py-1 border rounded-md text-sm">Advance Stage</button>
        <button onClick={recordPayment} className="px-2 py-1 bg-green-600 text-white rounded-md text-sm">Record</button>
        <button onClick={()=>{ if(window.confirm('Delete project?')) onDelete(p.id)}} className="px-2 py-1 text-red-600 border rounded-md text-sm">Delete</button>
      </div>
    </div>
  )
}

function NocPage({ nocs, clients, onAdd, onUpdate }) {
  const [form, setForm] = useState({ clientId: clients[0]?.id || '', siteAddress: '', remarks: '' })

  useEffect(()=>{ if (!form.clientId && clients[0]) setForm(f => ({ ...f, clientId: clients[0].id })) }, [clients])

  const submit = (e) => { e.preventDefault(); if(!form.siteAddress) return alert('Site address required'); onAdd(form); setForm({ clientId: clients[0]?.id || '', siteAddress:'', remarks:'' }) }

  return (
    <div className="space-y-4">
      <h2 className="text-lg font-semibold">NOC & Drawing Submissions</h2>
      <form onSubmit={submit} className="grid grid-cols-1 md:grid-cols-3 gap-2">
        <div>
          <label className="text-sm">Client</label>
          <select value={form.clientId} onChange={e=>setForm({...form,clientId:e.target.value})} className="w-full p-2 rounded-md border">
            {clients.map(c=> <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </div>
        <div>
          <label className="text-sm">Site Address</label>
          <input value={form.siteAddress} onChange={e=>setForm({...form,siteAddress:e.target.value})} className="w-full p-2 rounded-md border" />
        </div>
        <div>
          <label className="text-sm">Remarks</label>
          <input value={form.remarks} onChange={e=>setForm({...form,remarks:e.target.value})} className="w-full p-2 rounded-md border" />
        </div>
        <div className="md:col-span-3">
          <button className="px-4 py-2 bg-teal-600 text-white rounded-md">Create NOC File</button>
        </div>
      </form>

  <div className="space-y-2">
    {nocs.map(n => <NocCard key={n.id} n={n} clients={clients} onUpdate={onUpdate} />)}
    {nocs.length===0 && <div className="text-sm text-gray-500">No NOC files yet.</div>}
  </div>
</div>
  )
}

function NocCard({ n, clients, onUpdate }) {
  const client = clients.find(c=>c.id===n.clientId)
  const addLog = () => {
    const t = prompt('Status update (e.g., Submitted / Pending / Approved)')
    if (t) onUpdate(n.id, { logs: [{ time: Date.now(), txt: t }, ...(n.logs || [])], status: t.toLowerCase() })
  }
  return (
    <div className="p-3 bg-white rounded-md shadow-sm flex justify-between items-center">
      <div>
        <div className="font-medium">{client?.name || '—'}</div>
        <div className="text-xs text-gray-500">Address: {n.siteAddress}</div>
        <div className="text-xs text-gray-500">Status: {n.status}</div>
      </div>
      <div className="flex gap-2">
        <button onClick={addLog} className="px-2 py-1 border rounded-md text-sm">Update Status</button>
      </div>
    </div>
  )
}

function ValuationPage({ valuations, banks, clients, onAdd, onUpdate }) {
  const [form, setForm] = useState({ clientId: clients[0]?.id || '', bankName: '', siteAddress: '' })

  useEffect(()=>{ if (!form.clientId && clients[0]) setForm(f => ({ ...f, clientId: clients[0].id })) }, [clients])

  const submit = (e) => { e.preventDefault(); if(!form.bankName) return alert('Bank Name required'); onAdd(form); setForm({ clientId: clients[0]?.id || '', bankName:'', siteAddress:'' }) }

  return (
    <div className="space-y-4">
      <h2 className="text-lg font-semibold">Valuation Reports</h2>
      <form onSubmit={submit} className="grid grid-cols-1 md:grid-cols-3 gap-2">
        <div>
          <label className="text-sm">Bank Name</label>
          <input value={form.bankName} onChange={e=>setForm({...form,bankName:e.target.value})} className="w-full p-2 rounded-md border" />
        </div>
        <div>
          <label className="text-sm">Client</label>
          <select value={form.clientId} onChange={e=>setForm({...form,clientId:e.target.value})} className="w-full p-2 rounded-md border">
            {clients.map(c=> <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </div>
        <div>
          <label className="text-sm">Site Address</label>
          <input value={form.siteAddress} onChange={e=>setForm({...form,siteAddress:e.target.value})} className="w-full p-2 rounded-md border" />
        </div>
        <div className="md:col-span-3">
          <button className="px-4 py-2 bg-teal-600 text-white rounded-md">Create Valuation Job</button>
        </div>
      </form>

      <div className="space-y-2">
        {valuations.map(v => <ValCard key={v.id} v={v} clients={clients} onUpdate={onUpdate} />)}
        {valuations.length===0 && <div className="text-sm text-gray-500">No valuation jobs yet.</div>}
      </div>
    </div>
  )
}

function ValCard({ v, clients, onUpdate }) {
  const client = clients.find(c=>c.id===v.clientId)
  const markReady = () => onUpdate(v.id, { status: 'report-ready', logs: [{ time: Date.now(), txt: 'Report prepared' }, ...(v.logs||[])] })
  const deliver = () => onUpdate(v.id, { status: 'delivered', logs: [{ time: Date.now(), txt: 'Delivered to bank/client' }, ...(v.logs||[])] })

  return (
    <div className="p-3 bg-white rounded-md shadow-sm flex justify-between items-center">
      <div>
        <div className="font-medium">{v.bankName} — {client?.name || '—'}</div>
        <div className="text-xs text-gray-500">{v.siteAddress}</div>
        <div className="text-xs text-gray-500">Status: {v.status}</div>
      </div>
      <div className="flex gap-2">
        <button onClick={markReady} className="px-2 py-1 border rounded-md text-sm">Mark Ready</button>
        <button onClick={deliver} className="px-2 py-1 bg-teal-600 text-white rounded-md text-sm">Deliver</button>
      </div>
    </div>
  )
}

function ClientsPage({ clients, employees, setClients, setEmployees }) {
  const [cform, setCform] = useState({ name: '', phone: '' })
  const [eform, setEform] = useState({ name: '', role: '' })

  const addClient = (e) => { e.preventDefault(); if(!cform.name) return; setClients([ { id: uid('c'), ...cform }, ...clients]); setCform({ name:'', phone:'' }) }
  const addEmployee = (e) => { e.preventDefault(); if(!eform.name) return; setEmployees([ { id: uid('e'), ...eform }, ...employees]); setEform({ name:'', role:'' }) }

  return (
    <div className="space-y-4">
      <h2 className="text-lg font-semibold">Clients & Employees</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="p-3 bg-white rounded-md shadow-sm">
          <h3 className="font-medium mb-2">Add Client</h3>
          <form onSubmit={addClient} className="space-y-2">
            <input value={cform.name} onChange={e=>setCform({...cform,name:e.target.value})} className="w-full p-2 border rounded-md" placeholder="Name" />
            <input value={cform.phone} onChange={e=>setCform({...cform,phone:e.target.value})} className="w-full p-2 border rounded-md" placeholder="Phone" />
            <button className="px-3 py-2 bg-teal-600 text-white rounded-md">Add Client</button>
          </form>
        </div>

        <div className="p-3 bg-white rounded-md shadow-sm">
          <h3 className="font-medium mb-2">Add Employee</h3>
          <form onSubmit={addEmployee} className="space-y-2">
            <input value={eform.name} onChange={e=>setEform({...eform,name:e.target.value})} className="w-full p-2 border rounded-md" placeholder="Name" />
            <input value={eform.role} onChange={e=>setEform({...eform,role:e.target.value})} className="w-full p-2 border rounded-md" placeholder="Role" />
            <button className="px-3 py-2 bg-teal-600 text-white rounded-md">Add Employee</button>
          </form>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="p-3 bg-white rounded-md shadow-sm">
          <h3 className="font-medium mb-2">Clients</h3>
          <div className="space-y-1">
            {clients.map(c => <div key={c.id} className="text-sm">{c.name} • {c.phone}</div>)}
          </div>
        </div>
        <div className="p-3 bg-white rounded-md shadow-sm">
          <h3 className="font-medium mb-2">Employees</h3>
          <div className="space-y-1">
            {employees.map(e => <div key={e.id} className="text-sm">{e.name} • {e.role}</div>)}
          </div>
        </div>
      </div>
    </div>
  )
}

function PaymentsPage({ projects, onUpdate }) {
  const pay = (p) => {
    const amt = parseInt(prompt('Amount received (₹)', '0') || '0')
    if (amt>0) onUpdate(p.id, { payments: { ...p.payments, received: (p.payments?.received||0) + amt } })
  }

  return (
    <div>
      <h2 className="text-lg font-semibold">Payments</h2>
      <div className="space-y-2 mt-2">
        {projects.map(p => (
          <div key={p.id} className="p-3 bg-white rounded-md shadow-sm flex justify-between">
            <div>
              <div className="font-medium">{p.title}</div>
              <div className="text-xs text-gray-500">Total: ₹{p.payments?.total} • Received: ₹{p.payments?.received || 0}</div>
            </div>
            <div className="flex gap-2">
              <button onClick={()=>pay(p)} className="px-3 py-1 bg-green-600 text-white rounded-md">Record</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
