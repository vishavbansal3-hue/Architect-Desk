// Preload (empty for now). Add secure bridges if needed.
window.addEventListener('DOMContentLoaded', () => {
  // placeholder
});
