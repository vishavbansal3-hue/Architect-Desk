
# Architect Desk - Ready-to-build Project

This archive contains a ready-to-build React + Tailwind project scaffold for *Architect Desk*.
It includes configuration files for Electron (desktop) and Capacitor (mobile) so you can package
the app for Windows (.exe), Android (.apk), and iOS (.ipa).

## Quick start (development)
1. Install dependencies:
   ```
   npm install
   ```

2. Run dev server:
   ```
   npm run dev
   ```
   Open http://localhost:5173

## Build web
```
npm run build:web
```
This creates a `dist/` folder (static files). For desktop/mobile packaging the wrappers use `dist`.

## Desktop (Electron)
- Start in dev (optional):
  ```
  ELECTRON_START_URL=http://localhost:5173 npm start
  ```

- To build a distributable `.exe` use electron-builder (you must configure it further for signing, icons, etc):
  ```
  npm run build:desktop
  ```

## Mobile (Capacitor)
After building web (`npm run build:web`):
```
npx cap init "Architect Desk" "com.architect.desk"
npx cap add android
npx cap add ios
npx cap copy
npx cap open android
npx cap open ios
```
Use Android Studio / Xcode to build the actual .apk/.ipa.

## Notes
- Sample data is included in `src/App.jsx` and stored in localStorage. You can delete sample entries later from the UI.
- For production you should split components, add secure storage, and add a backend.
